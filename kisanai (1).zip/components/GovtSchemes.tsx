import React, { useState, useEffect } from 'react';
import { getGovtSchemes, generateSpeech } from '../services/gemini';
import { Language, UserProfile } from '../types';
import { Landmark, Check, Volume2 } from 'lucide-react';
import { TRANSLATIONS } from '../constants/translations';
import Header from './Header';

interface Props {
  language: Language;
  profile: UserProfile;
  isAiOn: boolean;
  onBack?: () => void;
}

const GovtSchemes: React.FC<Props> = ({ language, profile, isAiOn, onBack }) => {
  const [schemes, setSchemes] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const t = TRANSLATIONS[language];

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const data = await getGovtSchemes(profile, language);
        setSchemes(data.schemes);
        if (isAiOn && data.schemes.length > 0) {
            generateSpeech(`I found ${data.schemes.length} schemes for you in ${profile.district}.`, language);
        }
      } catch(e) {} finally { setLoading(false); }
    };
    fetch();
  }, [profile, language]);

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <Header title={t.govtSupport} onBack={onBack} language={language} />
      
      <div className="max-w-2xl mx-auto p-4">
        {loading ? (
            <div className="text-center p-10 text-slate-400 flex flex-col items-center gap-2">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
                Finding schemes...
            </div>
        ) : (
            <div className="space-y-4">
                {schemes.map((s, i) => (
                    <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition animate-slide-up" style={{ animationDelay: `${i*150}ms` }}>
                    <div className="flex justify-between mb-3">
                        <h3 className="text-lg font-bold text-purple-800 w-3/4">{s.name}</h3>
                        <Landmark className="w-6 h-6 text-purple-300" />
                    </div>
                    
                    <div className="space-y-3 mb-4">
                        <p className="text-slate-700 bg-purple-50 p-3 rounded-xl text-sm">{s.benefits}</p>
                        <div className="flex gap-2 items-start text-xs text-slate-500">
                        <Check className="w-4 h-4 text-green-500 shrink-0" />
                        <span>{s.eligibility}</span>
                        </div>
                    </div>

                    <div className="flex gap-2">
                        <button className="flex-1 py-2 bg-purple-600 text-white rounded-lg font-medium text-sm">{t.applyNow}</button>
                        <button 
                        onClick={() => generateSpeech(s.benefits, language)}
                        className="p-2 text-purple-600 bg-purple-50 rounded-lg"
                        >
                        <Volume2 className="w-5 h-5" />
                        </button>
                    </div>
                    </div>
                ))}
            </div>
        )}
      </div>
    </div>
  );
};

export default GovtSchemes;