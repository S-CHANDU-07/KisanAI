import React, { useState, useEffect } from 'react';
import { UserProfile, Language } from '../types';
import { Sprout, Loader2 } from 'lucide-react';
import { getGeminiGreeting, generateSpeech } from '../services/gemini';
import { auth, db } from '../services/firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { TRANSLATIONS } from '../constants/translations';

interface Props {
  onLogin: (profile: UserProfile) => void;
  language: Language;
  setLanguage: (l: Language) => void;
}

const Auth: React.FC<Props> = ({ onLogin, language, setLanguage }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState<UserProfile>({
    name: '',
    email: '',
    soilColor: 'Red',
    village: '',
    taluk: '',
    district: '',
    landSize: ''
  });
  const [password, setPassword] = useState('');
  
  const t = TRANSLATIONS[language];

  useEffect(() => {
    // Initial Greeting
    const greet = async () => {
      // Only greet once per session or if language changes significantly, simple check here
      const text = await getGeminiGreeting(language);
      if(text) generateSpeech(text, language);
    };
    // greet(); // Optional: Uncomment if you want audio greeting every time auth loads
  }, [language]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      if (isLogin) {
        // Login Logic
        const userCredential = await signInWithEmailAndPassword(auth, formData.email, password);
        const user = userCredential.user;
        
        // Fetch user profile from Firestore
        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const profileData = docSnap.data() as UserProfile;
          onLogin(profileData);
        } else {
          // Fallback if auth exists but no profile (legacy users)
          onLogin({ ...formData, name: user.displayName || 'Farmer' });
        }
      } else {
        // Sign Up Logic
        const userCredential = await createUserWithEmailAndPassword(auth, formData.email, password);
        const user = userCredential.user;

        // Update Auth Profile (Display Name)
        await updateProfile(user, { displayName: formData.name });

        // Save full profile to Firestore
        const profileData: UserProfile = {
            ...formData,
            email: user.email || formData.email
        };
        
        await setDoc(doc(db, "users", user.uid), profileData);
        onLogin(profileData);
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found') {
        setError("Invalid email or password. If you are new, please Sign Up.");
      } else if (err.code === 'auth/email-already-in-use') {
        setError("Email already registered. Please login.");
      } else if (err.code === 'auth/network-request-failed') {
        setError("Network error. Please check your connection.");
      } else {
        setError("Error: " + (err.message || "Authentication failed"));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="bg-white w-full max-w-md p-8 rounded-2xl shadow-xl border border-emerald-100 animate-slide-up">
        <div className="flex justify-center mb-6">
          <div className="bg-emerald-100 p-3 rounded-full">
            <Sprout className="w-10 h-10 text-emerald-600" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-center text-slate-800 mb-2">
          {isLogin ? t.welcome : t.join}
        </h2>
        <p className="text-center text-slate-500 mb-6 text-sm">
          {t.tagline}
        </p>

        <div className="flex justify-center mb-6">
           <select 
             value={language}
             onChange={(e) => setLanguage(e.target.value as Language)}
             className="bg-slate-100 border-none rounded-full px-4 py-1 text-sm font-medium text-slate-700"
           >
             <option value={Language.ENGLISH}>English</option>
             <option value={Language.HINDI}>हिंदी</option>
             <option value={Language.KANNADA}>ಕನ್ನಡ</option>
           </select>
        </div>

        {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100 text-center">
                {error}
            </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="animate-slide-up">
              <input name="name" placeholder={t.namePlaceholder} required className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
            </div>
          )}
          
          <input name="email" type="email" placeholder={t.emailPlaceholder} required className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
          <input name="password" type="password" placeholder={t.passwordPlaceholder} required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" />

          {!isLogin && (
            <div className="space-y-4 animate-slide-up delay-100">
               <div className="grid grid-cols-2 gap-3">
                  <select name="soilColor" className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange}>
                    <option value="Red">Red Soil</option>
                    <option value="Black">Black Soil</option>
                    <option value="Alluvial">Alluvial</option>
                    <option value="Laterite">Laterite</option>
                  </select>
                  <input name="landSize" placeholder={t.landPlaceholder} className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
               </div>
               <input name="village" placeholder={t.villagePlaceholder} required className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
               <div className="grid grid-cols-2 gap-3">
                  <input name="taluk" placeholder={t.talukPlaceholder} required className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
                  <input name="district" placeholder={t.districtPlaceholder} required className="w-full p-3 bg-slate-50 border rounded-lg outline-none focus:ring-2 focus:ring-emerald-500" onChange={handleChange} />
               </div>
            </div>
          )}

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg shadow-lg transform transition active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLogin ? t.loginBtn : t.signupBtn)}
          </button>
        </form>

        <div className="mt-4 text-center">
          <button onClick={() => { setIsLogin(!isLogin); setError(''); }} className="text-emerald-600 text-sm font-medium hover:underline">
            {isLogin ? t.noAccount : t.haveAccount}
          </button>
        </div>

        <div className="mt-8 text-center text-xs text-slate-400">
           <p>KisanAI Founder: S Chandu</p>
        </div>
      </div>
    </div>
  );
};

export default Auth;