import React from 'react';
import { ChevronLeft } from 'lucide-react';
import { Language } from '../types';

interface Props {
  title: string;
  onBack?: () => void;
  language: Language;
}

const Header: React.FC<Props> = ({ title, onBack, language }) => {
  return (
    <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-100 px-4 py-3 flex items-center gap-3 shadow-sm animate-slide-up">
      {onBack && (
        <button 
          onClick={onBack}
          className="p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors active:scale-95"
        >
          <ChevronLeft className="w-6 h-6 text-slate-600" />
        </button>
      )}
      <h1 className="text-lg font-bold text-slate-800 flex-1">{title}</h1>
    </div>
  );
};

export default Header;