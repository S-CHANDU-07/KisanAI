import React, { useState, useRef } from 'react';
import { analyzeCropDisease, generateSpeech } from '../services/gemini';
import { Language, UserProfile } from '../types';
import { Camera, ShieldCheck, AlertTriangle, Volume2 } from 'lucide-react';
import { TRANSLATIONS } from '../constants/translations';
import Header from './Header';

interface Props {
  language: Language;
  profile: UserProfile;
  isAiOn: boolean;
  onBack?: () => void;
}

const DiseaseDetection: React.FC<Props> = ({ language, isAiOn, onBack }) => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = TRANSLATIONS[language];

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const analyze = async () => {
    if(!image) return;
    setLoading(true);
    try {
      const data = await analyzeCropDisease(image.split(',')[1], language);
      setResult(data);
      if(isAiOn) generateSpeech(`${data.diseaseName}. ${data.solution}`, language);
    } catch(e: any) { 
        alert(e.message || "Analysis failed. Please try again."); 
    } finally { 
        setLoading(false); 
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <Header title={t.doctor} onBack={onBack} language={language} />
      
      <div className="max-w-2xl mx-auto p-4">
        {!result ? (
          <div className="bg-white rounded-3xl p-8 text-center shadow-lg border-2 border-dashed border-slate-200" onClick={() => fileInputRef.current?.click()}>
             {image ? (
               <img src={image} className="max-h-64 mx-auto rounded-xl shadow-md mb-6" alt="Preview" />
             ) : (
               <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                 <Camera className="w-10 h-10" />
               </div>
             )}
             <h3 className="text-lg font-bold text-slate-700 mb-1">
               {image ? t.tapToScan : t.takePhoto}
             </h3>
             <p className="text-slate-400 text-sm mb-6">{t.uploadPrompt}</p>
             
             <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFile} />
             
             {image && (
               <button 
                 onClick={(e) => { e.stopPropagation(); analyze(); }}
                 className="w-full bg-amber-500 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-amber-600 transition"
               >
                 {loading ? t.scanning : t.detectBtn}
               </button>
             )}
          </div>
        ) : (
          <div className="bg-white rounded-3xl overflow-hidden shadow-xl animate-slide-up">
            <div className={`p-6 ${result.diseaseName === 'Healthy' ? 'bg-green-500' : 'bg-red-500'} text-white`}>
               <div className="flex justify-between items-start">
                 <div>
                    <h2 className="text-2xl font-bold mb-1">{result.diseaseName}</h2>
                    <p className="opacity-90">{result.cause}</p>
                 </div>
                 {result.diseaseName === 'Healthy' ? <ShieldCheck className="w-8 h-8" /> : <AlertTriangle className="w-8 h-8" />}
               </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="bg-amber-50 rounded-2xl p-5 border border-amber-100">
                 <h3 className="font-bold text-amber-800 mb-2">{t.solution}</h3>
                 <p className="text-amber-900">{result.solution}</p>
              </div>
              
              <div>
                 <h3 className="font-bold text-slate-700 mb-2">{t.prevention}</h3>
                 <p className="text-slate-600 text-sm">{result.prevention}</p>
              </div>

              <button 
                 onClick={() => setResult(null)}
                 className="w-full py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50"
              >
                {t.scanAnother}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DiseaseDetection;