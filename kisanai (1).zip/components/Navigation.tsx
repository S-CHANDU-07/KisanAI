import React from 'react';
import { AppView, Language } from '../types';
import { Home, Sprout, Cloud, User } from 'lucide-react';
import { TRANSLATIONS } from '../constants/translations';

interface Props {
  view: AppView;
  setView: (v: AppView) => void;
  language: Language;
}

const Navigation: React.FC<Props> = ({ view, setView, language }) => {
  if (view === AppView.AUTH) return null;

  const t = TRANSLATIONS[language];

  const tabs = [
    { id: AppView.HOME, icon: Home, label: t.navHome },
    { id: AppView.CROP_REC, icon: Sprout, label: t.navCrops },
    { id: AppView.WEATHER, icon: Cloud, label: t.navWeather },
    { id: AppView.ACCOUNT, icon: User, label: t.navAccount },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 pb-safe z-40">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setView(tab.id)}
            className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
              view === tab.id ? 'text-emerald-600' : 'text-slate-400'
            }`}
          >
            <tab.icon className={`w-6 h-6 ${view === tab.id ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-medium">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Navigation;