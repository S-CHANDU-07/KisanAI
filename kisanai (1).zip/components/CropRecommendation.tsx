import React, { useState } from 'react';
import { getCropRecommendation, generateSpeech } from '../services/gemini';
import { Language, UserProfile } from '../types';
import { Leaf, TrendingUp, Volume2 } from 'lucide-react';
import { TRANSLATIONS } from '../constants/translations';
import Header from './Header';

interface Props {
  language: Language;
  profile: UserProfile;
  isAiOn: boolean;
}

const CropRecommendation: React.FC<Props> = ({ language, profile, isAiOn }) => {
  const [season, setSeason] = useState('Monsoon');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const t = TRANSLATIONS[language];

  const handleAnalysis = async () => {
    setLoading(true);
    setResults([]);
    try {
      const data = await getCropRecommendation(profile, season, language);
      setResults(data);
      if (isAiOn && data.length > 0) {
        generateSpeech(`Based on your ${profile.soilColor} soil in ${profile.district}, I suggest ${data.map((d:any)=>d.cropName).join(', ')}.`, language);
      }
    } catch (err) {
      alert("Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <Header title={t.cropTitle} language={language} />
      
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-emerald-50">
          <h2 className="text-xl font-bold text-emerald-800 mb-4 flex items-center gap-2">
            <Leaf className="w-5 h-5" /> {t.cropTitle}
          </h2>
          <div className="flex gap-4">
            <select 
              value={season} 
              onChange={(e) => setSeason(e.target.value)}
              className="flex-1 p-3 bg-emerald-50 border-none rounded-xl text-emerald-900 font-medium outline-none"
            >
              <option value="Monsoon">{t.monsoon}</option>
              <option value="Winter">{t.winter}</option>
              <option value="Summer">{t.summer}</option>
            </select>
            <button 
              onClick={handleAnalysis}
              disabled={loading}
              className="px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold shadow-emerald-200 shadow-lg hover:bg-emerald-700 disabled:opacity-50 transition-all"
            >
              {loading ? t.analyzing : t.analyzeBtn}
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {results.map((crop, idx) => (
            <div key={idx} className={`bg-white rounded-2xl p-5 shadow-sm border border-slate-100 animate-slide-up`} style={{ animationDelay: `${idx * 150}ms` }}>
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-xl font-bold text-slate-800">{crop.cropName}</h3>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${crop.profitability.includes('High') ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                  {crop.profitability} {t.profit}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="text-xs text-slate-500 uppercase font-bold tracking-wider">{t.demand}</span>
                  <p className="font-semibold text-slate-700 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4 text-blue-500" /> {crop.demand}
                  </p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <span className="text-xs text-slate-500 uppercase font-bold tracking-wider">{t.reason}</span>
                  <p className="text-sm text-slate-700 line-clamp-2">{crop.reason}</p>
                </div>
              </div>

              <button 
                 onClick={() => generateSpeech(crop.reason, language)}
                 className="w-full py-2 flex items-center justify-center gap-2 text-emerald-600 font-medium bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors"
              >
                <Volume2 className="w-4 h-4" /> {t.listen}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CropRecommendation;