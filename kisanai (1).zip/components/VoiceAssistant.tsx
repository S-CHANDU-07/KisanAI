import React, { useEffect, useRef, useState } from 'react';
import { LiveServerMessage, Modality } from '@google/genai';
import { getLiveClient } from '../services/gemini';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from '../services/audioUtils';
import { Mic, MicOff, Radio, AlertCircle } from 'lucide-react';
import { Language } from '../types';

interface Props {
  language: Language;
}

const VoiceAssistant: React.FC<Props> = ({ language }) => {
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState("Tap to speak");
  const [isError, setIsError] = useState(false);
  
  // Refs for audio handling to avoid re-renders
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Track intention to prevent race conditions
  const shouldBeActiveRef = useRef(false);

  const ai = getLiveClient();

  const stopSession = () => {
    shouldBeActiveRef.current = false;
    setActive(false);
    setStatus("Tap to speak");
    setIsError(false);
    
    // Cleanup Audio Context & Nodes
    if (audioContextRef.current) {
        if (audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(() => {});
        }
        audioContextRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    
    activeSourcesRef.current.forEach(source => {
      try { source.stop(); } catch(e) {}
    });
    activeSourcesRef.current.clear();

    // Close session if it exists
    if (sessionPromiseRef.current) {
        sessionPromiseRef.current.then(session => {
            try { session.close(); } catch(e) {}
        }).catch(() => {}); // Ignore connection failures during close
        sessionPromiseRef.current = null;
    }
  };

  const startSession = async () => {
    if (shouldBeActiveRef.current) return;
    
    if (!navigator.onLine) {
        setIsError(true);
        setStatus("No Internet");
        setTimeout(() => {
            if (!shouldBeActiveRef.current) setStatus("Tap to speak");
            setIsError(false);
        }, 2000);
        return;
    }

    shouldBeActiveRef.current = true;
    setIsError(false);
    setStatus("Connecting...");
    setActive(true); // UI shows active immediately to give feedback

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // If user stopped while waiting for permission
      if (!shouldBeActiveRef.current) {
          stream.getTracks().forEach(t => t.stop());
          return;
      }
      mediaStreamRef.current = stream;

      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;
      nextStartTimeRef.current = outputAudioContext.currentTime;

      const config = {
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            if (!shouldBeActiveRef.current) {
                // Close immediately if we shouldn't be active
                sessionPromiseRef.current?.then(s => s.close());
                return;
            }
            setStatus("Listening...");
            
            // Setup Input Processing
            const source = inputAudioContext.createMediaStreamSource(stream);
            sourceRef.current = source;
            const processor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              if (!shouldBeActiveRef.current) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              sessionPromiseRef.current?.then(session => {
                try {
                    session.sendRealtimeInput({ media: pcmBlob });
                } catch(e) {}
              });
            };

            source.connect(processor);
            processor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (!shouldBeActiveRef.current) return;
            
            // Handle Audio
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
               setStatus("Speaking...");
               try {
                 const audioBytes = base64ToUint8Array(base64Audio);
                 if (audioBytes.byteLength > 0) {
                     nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                     const audioBuffer = await decodeAudioData(audioBytes, outputAudioContext);
                     const source = outputAudioContext.createBufferSource();
                     source.buffer = audioBuffer;
                     source.connect(outputAudioContext.destination);
                     source.addEventListener('ended', () => {
                       activeSourcesRef.current.delete(source);
                       if (activeSourcesRef.current.size === 0 && shouldBeActiveRef.current) {
                           setStatus("Listening...");
                       }
                     });
                     source.start(nextStartTimeRef.current);
                     activeSourcesRef.current.add(source);
                     nextStartTimeRef.current += audioBuffer.duration;
                 }
               } catch (e) {}
            }

            if (message.serverContent?.interrupted) {
              activeSourcesRef.current.forEach(src => { try { src.stop(); } catch(e) {} });
              activeSourcesRef.current.clear();
              nextStartTimeRef.current = outputAudioContext.currentTime;
              setStatus("Listening...");
            }
            
            if (message.serverContent?.turnComplete) {
                if (activeSourcesRef.current.size === 0) setStatus("Listening...");
            }
          },
          onclose: () => {
             if (shouldBeActiveRef.current) {
                 stopSession();
             }
          },
          onerror: (err: any) => {
            console.error(err);
            if (!shouldBeActiveRef.current) return;
            setIsError(true);
            const msg = err.message || JSON.stringify(err);
            if (msg.includes('429') || msg.includes('quota')) {
                 setStatus("Quota Limit");
            } else {
                 setStatus("Network Error");
            }
            setTimeout(() => stopSession(), 2000);
          }
        },
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            systemInstruction: `You are Kisan Sahayak, a helpful AI assistant for Indian farmers. 
            Speak simply. You understand Hindi, Kannada, and English. 
            Always reply in ${language} language unless asked otherwise.
            Keep answers concise and helpful regarding farming, weather, and crops.`
        }
      };

      const sessionPromise = ai.live.connect(config);
      sessionPromiseRef.current = sessionPromise;
      
      // Catch connection establishment errors (Network Error comes here)
      sessionPromise.catch(e => {
          console.error("Connect failed", e);
          if (shouldBeActiveRef.current) {
             setIsError(true);
             setStatus("Connection Failed");
             setTimeout(() => stopSession(), 2000);
          }
      });

    } catch (e: any) {
      console.error(e);
      if (shouldBeActiveRef.current) {
          setIsError(true);
          setStatus("Mic Error");
          setTimeout(() => stopSession(), 2000);
      }
    }
  };

  useEffect(() => {
    return () => {
        stopSession();
    };
  }, []);

  return (
    <div className="fixed bottom-24 right-5 z-50">
      {active && (
        <div className="absolute bottom-20 right-0 w-48 bg-stone-900/90 backdrop-blur-md text-white p-3 rounded-2xl shadow-2xl mb-2 animate-slide-up border border-stone-700">
             <div className="flex items-center gap-2 mb-1">
                {isError ? (
                    <AlertCircle className="w-4 h-4 text-red-400" />
                ) : (
                    <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                )}
                <span className={`text-[10px] font-bold uppercase tracking-wider ${isError ? 'text-red-400' : 'text-emerald-400'}`}>
                    {isError ? 'Error' : 'Live'}
                </span>
             </div>
             <p className="text-xs font-medium text-stone-200">{status}</p>
        </div>
      )}
      
      <button
        onClick={active ? stopSession : startSession}
        className={`w-16 h-16 rounded-full shadow-xl flex items-center justify-center transition-all transform hover:scale-105 ${
          isError
            ? 'bg-red-600 hover:bg-red-700'
            : active 
                ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                : 'bg-emerald-600 hover:bg-emerald-700'
        }`}
      >
        {active ? (
          <MicOff className="w-8 h-8 text-white" />
        ) : (
          <Mic className="w-8 h-8 text-white" />
        )}
      </button>
    </div>
  );
};

export default VoiceAssistant;