import React, { useEffect, useState } from 'react';
import { getMarketData, getWeatherData, generateSpeech } from '../services/gemini';
import { Language, UserProfile } from '../types';
import { Cloud, Droplets, ShoppingBag, Volume2 } from 'lucide-react';
import { TRANSLATIONS } from '../constants/translations';
import Header from './Header';

interface Props {
  language: Language;
  profile: UserProfile;
  view: 'MARKET' | 'WEATHER';
  isAiOn: boolean;
  onBack?: () => void;
}

const MarketWeather: React.FC<Props> = ({ language, profile, view, isAiOn, onBack }) => {
  const [marketData, setMarketData] = useState<any>(null);
  const [weatherData, setWeatherData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const t = TRANSLATIONS[language];

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        if (view === 'MARKET') {
          const res = await getMarketData(profile, language);
          setMarketData(res.data);
          if (isAiOn && res.data) generateSpeech(`Market trend is ${res.data.trend}`, language);
        } else {
          const res = await getWeatherData(profile, language);
          setWeatherData(res);
          if (isAiOn && res) generateSpeech(`It is ${res.condition}. ${res.action}`, language);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [view, profile, language]);

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <Header 
        title={view === 'MARKET' ? t.mandi : t.weather} 
        onBack={view === 'MARKET' ? onBack : undefined} // Weather is a tab, no back needed normally, but if passed use it
        language={language} 
      />

      <div className="max-w-2xl mx-auto p-4">
        {loading ? (
          <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
          </div>
        ) : (
          <>
            {view === 'WEATHER' && weatherData && (
              <div className="space-y-4 animate-slide-up">
                <div className="bg-gradient-to-br from-sky-400 to-blue-500 rounded-3xl p-8 text-white shadow-lg text-center">
                  <Cloud className="w-16 h-16 mx-auto mb-2 opacity-90" />
                  <h1 className="text-5xl font-bold mb-1">{weatherData.temp}</h1>
                  <p className="text-xl font-medium opacity-90">{weatherData.condition}</p>
                  <p className="text-sm mt-2 opacity-75">{profile.village}</p>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 delay-100">
                  <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                    <Droplets className="w-5 h-5 text-blue-500" /> {t.farmAdvice}
                  </h3>
                  <p className="text-slate-600 mb-4">{weatherData.action}</p>
                  <button 
                    onClick={() => generateSpeech(weatherData.action, language)}
                    className="w-full py-2 bg-slate-50 text-slate-600 rounded-lg flex items-center justify-center gap-2 hover:bg-slate-100"
                  >
                    <Volume2 className="w-4 h-4" /> {t.listen}
                  </button>
                </div>
              </div>
            )}

            {view === 'MARKET' && marketData && (
              <div className="space-y-4 animate-slide-up">
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-emerald-100">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h2 className="text-lg font-bold text-slate-800">{marketData.mandiName}</h2>
                      <p className="text-xs text-slate-500">{t.livePrices}</p>
                    </div>
                    <div className="bg-emerald-100 p-2 rounded-full">
                      <ShoppingBag className="w-6 h-6 text-emerald-600" />
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {marketData.crops.map((c: any, i: number) => (
                      <div key={i} className="flex justify-between items-center p-3 bg-slate-50 rounded-xl animate-slide-up" style={{ animationDelay: `${i*100}ms` }}>
                          <span className="font-bold text-slate-700">{c.name}</span>
                          <span className="font-mono font-semibold text-emerald-600">{c.price}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-800 text-white rounded-2xl p-5 shadow-lg animate-slide-up delay-200">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-2">{t.marketInsight}</h3>
                  <p>{marketData.trend}</p>
                  <button 
                    onClick={() => generateSpeech(marketData.trend, language)}
                    className="mt-3 text-emerald-400 text-sm flex items-center gap-1"
                  >
                    <Volume2 className="w-4 h-4" /> {t.listen}
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default MarketWeather;