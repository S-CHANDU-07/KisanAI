import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Language, UserProfile } from "../types";
import { base64ToUint8Array, decodeAudioData } from "./audioUtils";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to get language name
const getLangName = (l: Language) => l === Language.HINDI ? 'Hindi' : l === Language.KANNADA ? 'Kannada' : 'English';

export const getGeminiGreeting = async (lang: Language) => {
  const prompt = `You are KisanAI. Generate a short, warm greeting in ${getLangName(lang)}. 
  Say: "Hi, Namaskara. If you don't know how to log in, I will guide you step by step." translated naturally.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "";
  } catch (e) { return ""; }
};

export const getCropRecommendation = async (
  profile: UserProfile,
  season: string,
  language: Language
) => {
  const prompt = `
    Act as an expert Indian agronomist. 
    Profile: 
    - Village: ${profile.village}
    - Taluk: ${profile.taluk}
    - District: ${profile.district}
    - Soil: ${profile.soilColor}
    - Land Size: ${profile.landSize || 'Unknown'}
    
    Season: ${season}.
    
    Recommend 10 profitable crops suited for this specific micro-climate and soil type.
    Output JSON array:
    [
      { "cropName": "...", "profitability": "High/Medium", "demand": "...", "reason": "Short explanation in ${getLangName(language)}" }
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', // Flash for speed, sufficient for this
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              cropName: { type: Type.STRING },
              profitability: { type: Type.STRING },
              demand: { type: Type.STRING },
              reason: { type: Type.STRING }
            }
          }
        }
      }
    });
    return response.text ? JSON.parse(response.text) : [];
  } catch (error) {
    console.error("Error getting crop recommendation:", error);
    throw error;
  }
};

export const analyzeCropDisease = async (
  imageBase64: string,
  language: Language
) => {
  try {
    // Switched to gemini-3-flash-preview for better quota handling and speed
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', 
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: imageBase64 } },
          {
            text: `Identify crop disease. Output JSON:
            { "diseaseName": "...", "cause": "...", "solution": "Simple solution in ${getLangName(language)}", "prevention": "..." }
            If healthy, diseaseName="Healthy".`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
         responseSchema: {
          type: Type.OBJECT,
          properties: {
            diseaseName: { type: Type.STRING },
            cause: { type: Type.STRING },
            solution: { type: Type.STRING },
            prevention: { type: Type.STRING }
          }
        }
      }
    });
    return response.text ? JSON.parse(response.text) : null;
  } catch (error: any) {
    console.error("Error analyzing disease:", error);
    if (error.message?.includes('429') || error.status === 429) {
        throw new Error("Daily AI limit reached. Please try again tomorrow.");
    }
    throw error;
  }
};

export const getMarketData = async (profile: UserProfile, language: Language) => {
  const prompt = `
    Get live mandi prices for 10 common crops in ${profile.district}, India.
    Output JSON:
    {
      "mandiName": "Nearest APMC...",
      "crops": [ {"name": "...", "price": "..."} ],
      "trend": "Short market trend summary in ${getLangName(language)}"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });
    return {
      data: response.text ? JSON.parse(response.text) : null,
      grounding: response.candidates?.[0]?.groundingMetadata
    };
  } catch (error) {
    console.error("Market data error", error);
    throw error;
  }
};

export const getWeatherData = async (profile: UserProfile, language: Language) => {
  const prompt = `
    Current weather for ${profile.village}, ${profile.district}.
    Output JSON:
    {
      "temp": "...",
      "condition": "...",
      "forecast": "...",
      "action": "One specific farm action (e.g. spray today?) in ${getLangName(language)}"
    }
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });
    return response.text ? JSON.parse(response.text) : null;
  } catch (error) {
    console.error("Weather error", error);
    throw error;
  }
};

export const getGovtSchemes = async (profile: UserProfile, language: Language) => {
  const prompt = `
    Find 3 active govt agriculture schemes for ${profile.district}, India.
    Output JSON Array:
    [
      { "name": "...", "benefits": "...", "eligibility": "...", "apply": "How to apply in ${getLangName(language)}" }
    ]
  `;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
         responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              benefits: { type: Type.STRING },
              eligibility: { type: Type.STRING },
              apply: { type: Type.STRING }
            }
          }
        }
      }
    });
    return {
      schemes: response.text ? JSON.parse(response.text) : [],
      grounding: response.candidates?.[0]?.groundingMetadata
    };
  } catch (error) {
    console.error("Schemes error", error);
    throw error;
  }
};

export const generateSpeech = async (text: string, language: Language) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text.slice(0, 400) }] }], // Limit length for speed
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }, // Neutral
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioBuffer = await decodeAudioData(base64ToUint8Array(base64Audio), audioContext, 24000, 1);
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);
      source.start();
    }
  } catch (error: any) {
    if (error.message?.includes('429')) {
       console.warn("TTS Quota exceeded. Skipping audio playback.");
       return;
    }
    console.error("TTS Error:", error);
  }
};

export const getLiveClient = () => ai;