import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB7qhvG4SKzjgcimiAzWfe7UUMM4D7iEys",
  authDomain: "chikkahomma-basava-balaga.firebaseapp.com",
  databaseURL: "https://chikkahomma-basava-balaga-default-rtdb.firebaseio.com",
  projectId: "chikkahomma-basava-balaga",
  storageBucket: "chikkahomma-basava-balaga.firebasestorage.app",
  messagingSenderId: "968228713650",
  appId: "1:968228713650:web:f53833cc83fecf840d85ab"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);