export enum Language {
  ENGLISH = 'English',
  HINDI = 'Hindi',
  KANNADA = 'Kannada'
}

export enum AppView {
  AUTH = 'AUTH',
  HOME = 'HOME',
  CROP_REC = 'CROP_REC',
  MARKET = 'MARKET',
  DISEASE_DETECTION = 'DISEASE_DETECTION',
  WEATHER = 'WEATHER',
  GOVT_SCHEMES = 'GOVT_SCHEMES',
  ACCOUNT = 'ACCOUNT',
  SETTINGS = 'SETTINGS',
  ABOUT = 'ABOUT',
  PRIVACY = 'PRIVACY'
}

export interface UserProfile {
  name: string;
  email: string;
  soilColor: string;
  village: string;
  taluk: string;
  district: string;
  landSize?: string;
}

export interface GroundingMetadata {
  groundingChunks?: {
    web?: { uri: string; title: string };
    maps?: { uri: string; title: string };
  }[];
}