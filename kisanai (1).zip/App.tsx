import React, { useState, useEffect } from 'react';
import Auth from './components/Auth';
import Navigation from './components/Navigation';
import CropRecommendation from './components/CropRecommendation';
import DiseaseDetection from './components/DiseaseDetection';
import MarketWeather from './components/MarketWeather';
import GovtSchemes from './components/GovtSchemes';
import VoiceAssistant from './components/VoiceAssistant';
import { AppView, Language, UserProfile } from './types';
import { Sprout, Cloud, ShoppingBag, ShieldCheck, Landmark, Settings, LogOut, ChevronRight, Loader2 } from 'lucide-react';
import { auth, db } from './services/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { TRANSLATIONS } from './constants/translations';
import Header from './components/Header'; // We might use it in Account/Settings too

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.AUTH);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isAiOn, setIsAiOn] = useState(true);
  const [loadingAuth, setLoadingAuth] = useState(true);

  // Persist Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // User is signed in, fetch profile
        try {
          const docRef = doc(db, "users", user.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
             setProfile(docSnap.data() as UserProfile);
             if (view === AppView.AUTH) setView(AppView.HOME);
          } else {
             // Profile missing in DB?
             setProfile({ name: user.email || 'User', email: user.email || '', soilColor: 'Red', village: 'Unknown', taluk: '', district: '' });
             if (view === AppView.AUTH) setView(AppView.HOME);
          }
        } catch (e) {
          console.error("Error fetching profile", e);
        }
      } else {
        // User is signed out
        setProfile(null);
        setView(AppView.AUTH);
      }
      setLoadingAuth(false);
    });

    return () => unsubscribe();
  }, [view]);

  const handleLogin = (user: UserProfile) => {
    setProfile(user);
    setView(AppView.HOME);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setProfile(null);
      setView(AppView.AUTH);
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  const goBack = () => setView(AppView.HOME);

  const t = TRANSLATIONS[language];

  const renderHome = () => (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-100 px-4 py-3 flex justify-between items-center shadow-sm animate-slide-up">
        <div>
          <h1 className="text-xl font-bold text-slate-800">{t.greeting}, {profile?.name.split(' ')[0]}</h1>
          <p className="text-slate-500 text-xs">{profile?.village}, {profile?.district}</p>
        </div>
        <button onClick={() => setView(AppView.SETTINGS)} className="p-2 bg-slate-100 rounded-full hover:bg-slate-200 transition">
           <Settings className="w-5 h-5 text-slate-600" />
        </button>
      </div>

      <div className="p-4 space-y-6">
        {/* Grid */}
        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => setView(AppView.CROP_REC)} className="bg-emerald-50 p-4 rounded-2xl text-left hover:bg-emerald-100 transition border border-emerald-100 shadow-sm active:scale-95">
             <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mb-3 shadow-sm">
               <Sprout className="w-5 h-5 text-emerald-600" />
             </div>
             <h3 className="font-bold text-slate-800">{t.cropPlan}</h3>
             <p className="text-xs text-slate-500 mt-1">{t.cropSubtitle}</p>
          </button>

          <button onClick={() => setView(AppView.MARKET)} className="bg-blue-50 p-4 rounded-2xl text-left hover:bg-blue-100 transition border border-blue-100 shadow-sm active:scale-95">
             <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mb-3 shadow-sm">
               <ShoppingBag className="w-5 h-5 text-blue-600" />
             </div>
             <h3 className="font-bold text-slate-800">{t.mandi}</h3>
             <p className="text-xs text-slate-500 mt-1">{t.mandiSubtitle}</p>
          </button>

          <button onClick={() => setView(AppView.DISEASE_DETECTION)} className="bg-amber-50 p-4 rounded-2xl text-left hover:bg-amber-100 transition border border-amber-100 shadow-sm active:scale-95">
             <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mb-3 shadow-sm">
               <ShieldCheck className="w-5 h-5 text-amber-600" />
             </div>
             <h3 className="font-bold text-slate-800">{t.doctor}</h3>
             <p className="text-xs text-slate-500 mt-1">{t.doctorSubtitle}</p>
          </button>

          <button onClick={() => setView(AppView.WEATHER)} className="bg-sky-50 p-4 rounded-2xl text-left hover:bg-sky-100 transition border border-sky-100 shadow-sm active:scale-95">
             <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mb-3 shadow-sm">
               <Cloud className="w-5 h-5 text-sky-600" />
             </div>
             <h3 className="font-bold text-slate-800">{t.weather}</h3>
             <p className="text-xs text-slate-500 mt-1">{t.weatherSubtitle}</p>
          </button>
        </div>

        <button onClick={() => setView(AppView.GOVT_SCHEMES)} className="w-full bg-purple-50 p-5 rounded-2xl flex items-center justify-between hover:bg-purple-100 transition border border-purple-100 shadow-sm active:scale-95">
          <div className="flex items-center gap-3">
            <div className="bg-white p-2 rounded-full shadow-sm">
               <Landmark className="w-6 h-6 text-purple-600" />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-slate-800">{t.schemes}</h3>
              <p className="text-xs text-slate-500">{t.schemesSubtitle}</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-purple-400" />
        </button>
      </div>
    </div>
  );

  const renderAccount = () => (
    <div className="bg-slate-50 min-h-screen pb-24">
      <Header title={t.myFarm} language={language} />
      <div className="p-4 space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-4">
           <div className="flex items-center gap-4 border-b border-slate-50 pb-4">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center text-2xl font-bold text-emerald-700 uppercase">
                {profile?.name.charAt(0)}
              </div>
              <div>
                <h3 className="font-bold text-lg">{profile?.name}</h3>
                <p className="text-slate-500 text-sm truncate max-w-[200px]">{profile?.email}</p>
              </div>
           </div>
           <div className="grid grid-cols-2 gap-4 text-sm">
             <div><p className="text-slate-400">{t.villagePlaceholder}</p><p className="font-medium">{profile?.village}</p></div>
             <div><p className="text-slate-400">{t.talukPlaceholder}</p><p className="font-medium">{profile?.taluk}</p></div>
             <div><p className="text-slate-400">{t.districtPlaceholder}</p><p className="font-medium">{profile?.district}</p></div>
             <div><p className="text-slate-400">Soil</p><p className="font-medium">{profile?.soilColor}</p></div>
             <div><p className="text-slate-400">Land</p><p className="font-medium">{profile?.landSize || '0'} Acres</p></div>
           </div>
        </div>
        <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 p-4 text-red-500 font-bold bg-red-50 rounded-xl hover:bg-red-100 transition">
          <LogOut className="w-5 h-5" /> {t.logout}
        </button>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="bg-slate-50 min-h-screen pb-24">
       <Header title={t.settings} onBack={goBack} language={language} />

       <div className="p-4 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 divide-y divide-slate-50">
             <div className="p-4 flex items-center justify-between">
                <div>
                    <span className="font-medium block">{t.aiVoice}</span>
                    <span className="text-xs text-slate-400">Always On / Auto-Read Results</span>
                </div>
                <button onClick={() => setIsAiOn(!isAiOn)} className={`w-12 h-6 rounded-full transition-colors relative ${isAiOn ? 'bg-emerald-500' : 'bg-slate-200'}`}>
                   <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${isAiOn ? 'left-7' : 'left-1'}`}></div>
                </button>
             </div>
             <div className="p-4 flex items-center justify-between">
                <span className="font-medium">{t.language}</span>
                <select 
                  value={language} 
                  onChange={(e) => setLanguage(e.target.value as Language)}
                  className="bg-slate-50 border-none rounded-lg text-sm p-2"
                >
                  <option value={Language.ENGLISH}>English</option>
                  <option value={Language.HINDI}>Hindi</option>
                  <option value={Language.KANNADA}>Kannada</option>
                </select>
             </div>
          </div>
          
          <div className="text-center text-xs text-slate-400 mt-10">
             <p>KisanAI v1.1.0</p>
             <p>Founder: S Chandu</p>
             <p>Powered by Google Gemini & Firebase</p>
          </div>
       </div>
    </div>
  );

  if (loadingAuth) {
      return (
          <div className="min-h-screen flex items-center justify-center bg-slate-50">
              <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-emerald-100">
      {view === AppView.AUTH || !profile ? (
        <Auth onLogin={handleLogin} language={language} setLanguage={setLanguage} />
      ) : (
        <>
          <main className="max-w-lg mx-auto bg-slate-50 min-h-screen shadow-2xl">
            {view === AppView.HOME && renderHome()}
            {view === AppView.CROP_REC && <CropRecommendation language={language} profile={profile} isAiOn={isAiOn} />}
            {view === AppView.MARKET && <MarketWeather language={language} profile={profile} view="MARKET" isAiOn={isAiOn} onBack={goBack} />}
            {view === AppView.WEATHER && <MarketWeather language={language} profile={profile} view="WEATHER" isAiOn={isAiOn} />}
            {view === AppView.DISEASE_DETECTION && <DiseaseDetection language={language} profile={profile} isAiOn={isAiOn} onBack={goBack} />}
            {view === AppView.GOVT_SCHEMES && <GovtSchemes language={language} profile={profile} isAiOn={isAiOn} onBack={goBack} />}
            {view === AppView.ACCOUNT && renderAccount()}
            {view === AppView.SETTINGS && renderSettings()}
          </main>
          <Navigation view={view} setView={setView} language={language} />
          {/* Voice Assistant is always mounted, preserving state across navigation */}
          <VoiceAssistant language={language} />
        </>
      )}
    </div>
  );
};

export default App;